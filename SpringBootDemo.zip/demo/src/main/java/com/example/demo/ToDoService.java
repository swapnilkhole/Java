package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class ToDoService {

	private List<ToDo> toDos = new ArrayList<>(Arrays.asList(new ToDo(1, "Task_1", "summary1", "desc_1"),
			new ToDo(2, "Task_2", "summary2", "desc_2"), new ToDo(3, "Task_3", "summary3", "desc_3")));

	public List<ToDo> getAllToDos() {
		return toDos;
	}

	public ToDo getToDo(Integer Id) {
		return toDos.stream().filter(t -> t.getId().equals(Id)).findFirst().get();
	}

	public boolean createToDo(ToDo todo) {
		return toDos.add(todo);

	}

	public void updateToDo(Integer id, ToDo todo) {
		System.out.println("updateToDo");
		for (int i = 0; i < toDos.size(); i++) {
			ToDo t = toDos.get(i);
			if (t.getId().equals(id)) {
				System.out.println("updating todo at " + i);
				toDos.set(i, todo);
			}
		}
	}
	
	public void deleteToDo(Integer id) {
		System.out.println("deleteToDo: " + id);
		toDos.removeIf(t -> t.getId().equals(id));
		System.out.println("deleteToDo success");
	}
}
